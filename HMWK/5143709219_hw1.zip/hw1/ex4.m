clear all;
clc;
disp('Number of grains required: ');
disp(intmax('uint64'));