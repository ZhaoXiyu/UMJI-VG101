function ex2
    clear all;
    clc;
    format long;
    fun = eval(['@(x)',input('input a function (in the form of matlab): f(x)= ','s')]);
    a=input('Input x_0,make sure f(x_0)<0, x_0 = ');
    b=input('Input x_1,make sure f(x_1)>0 x_1 = ');
    p=abs(input('Input percision e.g. 0.00001 : '));
    while abs(a-b)>p;
        t= rec(a,b,fun);
        if sign(fun(t))~=sign(fun(a));
            b=t;
        else 
            a=t;
        end;
    end;
    disp(['The root: ',num2str(round(0.5*(a+b)/p)*p,ceil(1/p))]);
end

function xn=rec(xn_2,xn_1,foo)
    xn = ( xn_2 *foo(xn_1) - xn_1*foo(xn_2) ) / ( foo(xn_1) - foo(xn_2) );
    return;
end